This video is the experiment results for the paper "3D Object Detection and Tracking Based on Streaming Data" in ICRA 2020. 

- Filename: icra_final_61.mp4
- Type: video/mp4
- Size: 19.5MB
- Time: 2 min 51 sec
- Resolution: 960 x 540 px

